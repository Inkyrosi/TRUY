//no permite los espacios
function noEspacios(event){
    if(event.keyCode === 32){
        event.preventDefault()
    }
}
//PERMITIR SOLO NUMEROS EN LOS CAMPOS 
function soloNumeros(event){
    const tecla = event.which ||event.keyCode;
    if(tecla < 48|| tecla >57){
        event.preventDefault();
    }
}